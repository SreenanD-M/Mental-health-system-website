from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
import google.generativeai as genai
from bson.objectid import ObjectId
import os
from dotenv import load_dotenv
import markdown
import json
import datetime
import re
from flask import flash

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your_secret_key_here')

# Configure Google Gemini API
genai.configure(api_key=os.getenv('GEMINI_API_KEY'))

# MongoDB Atlas connection
client = MongoClient(os.getenv('MONGO_URI'))
db = client.mental_health_app # Replace 'mental_health_app' with your desired database name

# Gemini model configuration
generation_config = {
  "temperature": 0.9,
  "top_p": 0.95,
  "top_k": 64,
  "max_output_tokens": 8192,
  "response_mime_type": "text/plain",
}

safety_settings = [
  {
    "category": "HARM_CATEGORY_HARASSMENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_HATE_SPEECH",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
  {
    "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
    "threshold": "BLOCK_MEDIUM_AND_ABOVE",
  },
]

# Initialize the model once
gemini_model = genai.GenerativeModel(
  model_name="gemini-1.5-flash",
  safety_settings=safety_settings,
  generation_config=generation_config,
)

# Initialize chat for mental health support
mental_health_chat = gemini_model.start_chat(
  history=[
    {
      "role": "user",
      "parts": [
        "I need you to act as a supportive mental health assistant. You should provide empathetic, helpful responses but clearly state you are not a replacement for professional mental health care.",
      ],
    },
    {
      "role": "model",
      "parts": [
        "I'll be your supportive mental health assistant. I'm here to listen and provide thoughtful responses to help you navigate your feelings and concerns. I'll do my best to offer useful perspectives and supportive guidance.\n\nPlease remember that while I'm here to support you, I'm not a licensed mental health professional and can't provide clinical advice or replace professional mental health care. If you're experiencing a crisis or need immediate help, please reach out to a qualified healthcare provider, counselor, or a crisis helpline.\n\nHow can I support you today?",
      ],
    },
  ]
)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/test_db')
def test_db():
    try:
        # The ismaster command is cheap and does not require auth.
        client.admin.command('ismaster')
        return "Database connection successful!"
    except Exception as e:
        return f"Database connection failed: {e}"

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        # Add other necessary fields here

        # Check if user already exists
        if db.users.find_one({'email': email}):
            # User already exists, handle this case (e.g., show an error message)
            return "User already exists!" # Placeholder

        hashed_password = generate_password_hash(password)
        
        # Insert new user into the database
        db.users.insert_one({
            'email': email,
            'password': hashed_password,
            'is_admin': False # Default to non-admin
            # Add other necessary fields here
        })

        return redirect(url_for('login')) # Redirect to login page after successful registration
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = db.users.find_one({'email': email})

        if user and check_password_hash(user['password'], password):
            # Login successful
            session['user_id'] = str(user['_id']) # Store user ID in session
            session['is_admin'] = user.get('is_admin', False) # Store admin status
            if session.get('is_admin'):
                return redirect(url_for('admin_dashboard')) # Redirect to admin dashboard if admin
            else:
                return redirect(url_for('index')) # Redirect to homepage for regular users
        else:
            # Login failed
            return "Invalid credentials!" # Placeholder
    return render_template('login.html')

def generate_quiz_questions(mood):
    """Generates quiz questions based on user's mood using Google Gemini."""
    try:
        prompt = f"Generate 5 multiple-choice questions about mental health tailored to someone feeling {mood}. Format each question as JSON with the following structure: {{\"question\": \"Question text\", \"options\": [\"Option A\", \"Option B\", \"Option C\", \"Option D\"], \"correct_answer\": \"Option X\"}}. Return a JSON array of these question objects."
        response = gemini_model.generate_content(prompt)
        # Return raw text for now - will be parsed into JSON in a later function
        return response.text
    except Exception as e:
        print(f"Error generating quiz questions: {e}")
        return None

@app.route('/quiz')
def quiz():
    # Show the quiz page (the actual questions will be loaded via AJAX)
    return render_template('quiz.html')

@app.route('/generate_quiz', methods=['POST'])
def generate_quiz():
    if request.method == 'POST':
        # Get the selected mood from the request
        mood = request.form.get('mood', 'neutral')
        
        try:
            # Generate questions based on the mood
            questions_text = generate_quiz_questions(mood)
            
            # If questions_text is None, return default questions
            if questions_text is None:
                print("No response from Gemini API, using default questions")
                default_questions = [
                    {
                        "question": "How often do you feel overwhelmed by your responsibilities?",
                        "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                        "correct_answer": "Sometimes"
                    },
                    {
                        "question": "Do you find yourself avoiding social interactions?",
                        "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                        "correct_answer": "Rarely"
                    },
                    {
                        "question": "How would you rate your sleep quality?",
                        "options": ["Excellent", "Good", "Fair", "Poor", "Very poor"],
                        "correct_answer": "Good"
                    },
                    {
                        "question": "How often do you engage in activities you enjoy?",
                        "options": ["Daily", "Several times a week", "Once a week", "Rarely", "Never"],
                        "correct_answer": "Several times a week"
                    },
                    {
                        "question": "Do you have someone you can talk to when you're feeling down?",
                        "options": ["Definitely yes", "Mostly yes", "Sometimes", "Rarely", "No"],
                        "correct_answer": "Mostly yes"
                    }
                ]
                return jsonify({"success": True, "questions": default_questions})
            
            # Try to parse the questions
            # This is a simple approach. In a production app, you'd want more robust parsing
            import json
            try:
                # Try to clean up and parse the JSON
                questions_text = questions_text.strip()
                if questions_text.startswith('```json'):
                    questions_text = questions_text.replace('```json', '', 1)
                if questions_text.endswith('```'):
                    questions_text = questions_text[:-3]
                
                questions = json.loads(questions_text.strip())
                return jsonify({"success": True, "questions": questions})
            except json.JSONDecodeError as e:
                # Fallback to default questions if JSON parsing fails
                print(f"Error parsing questions JSON: {e}")
                print(f"Original text: {questions_text}")
                
                # Return default questions
                default_questions = [
                    {
                        "question": "How often do you feel overwhelmed by your responsibilities?",
                        "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                        "correct_answer": "Sometimes"
                    },
                    {
                        "question": "Do you find yourself avoiding social interactions?",
                        "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                        "correct_answer": "Rarely"
                    },
                    {
                        "question": "How would you rate your sleep quality?",
                        "options": ["Excellent", "Good", "Fair", "Poor", "Very poor"],
                        "correct_answer": "Good"
                    },
                    {
                        "question": "How often do you engage in activities you enjoy?",
                        "options": ["Daily", "Several times a week", "Once a week", "Rarely", "Never"],
                        "correct_answer": "Several times a week"
                    },
                    {
                        "question": "Do you have someone you can talk to when you're feeling down?",
                        "options": ["Definitely yes", "Mostly yes", "Sometimes", "Rarely", "No"],
                        "correct_answer": "Mostly yes"
                    }
                ]
                return jsonify({"success": True, "questions": default_questions})
        except Exception as e:
            print(f"Error generating quiz: {e}")
            # Return default questions on error
            default_questions = [
                {
                    "question": "How often do you feel overwhelmed by your responsibilities?",
                    "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                    "correct_answer": "Sometimes"
                },
                {
                    "question": "Do you find yourself avoiding social interactions?",
                    "options": ["Never", "Rarely", "Sometimes", "Often", "All the time"],
                    "correct_answer": "Rarely"
                },
                {
                    "question": "How would you rate your sleep quality?",
                    "options": ["Excellent", "Good", "Fair", "Poor", "Very poor"],
                    "correct_answer": "Good"
                },
                {
                    "question": "How often do you engage in activities you enjoy?",
                    "options": ["Daily", "Several times a week", "Once a week", "Rarely", "Never"],
                    "correct_answer": "Several times a week"
                },
                {
                    "question": "Do you have someone you can talk to when you're feeling down?",
                    "options": ["Definitely yes", "Mostly yes", "Sometimes", "Rarely", "No"],
                    "correct_answer": "Mostly yes"
                }
            ]
            return jsonify({"success": True, "questions": default_questions})

@app.route('/process_quiz', methods=['POST'])
def process_quiz():
    if request.method == 'POST':
        try:
            # Get the answers from the form data
            answers = {}
            for key, value in request.form.items():
                if key.startswith('question_'):
                    question_id = key.split('_')[1]
                    answers[question_id] = value
            
            if not answers:
                # No answers provided
                return render_template('error.html', 
                                      title="Error Processing Quiz",
                                      message="No answers were provided. Please go back and complete the quiz.")
            
            # Get the mood information
            mood = request.form.get('mood', 'neutral')
            quiz_id = request.form.get('quiz_id', '0')
            
            # Process the answers and generate results
            # In a real app, you would have a more sophisticated scoring system
            score = len(answers)
            results = "Thank you for completing the quiz! Your responses have been recorded."
            
            # Generate personalized recommendations based on mood and answers
            recommendations = [
                {
                    "title": "Self-Care Practice", 
                    "description": "Dedicate time each day for activities that bring you joy and relaxation."
                },
                {
                    "title": "Regular Exercise", 
                    "description": "Even a short 20-minute walk can significantly improve your mood and mental well-being."
                },
                {
                    "title": "Mindfulness Meditation", 
                    "description": "Try our guided meditation sessions to reduce stress and improve focus."
                }
            ]
            
            # Save results to database if user is logged in
            if 'user_id' in session:
                try:
                    # Insert results
                    db.quiz_results.insert_one({
                        'user_id': session['user_id'],
                        'quiz_id': quiz_id,
                        'answers': answers,
                        'score': score,
                        'results': results,
                        'recommendations': recommendations,
                        'mood': mood,
                        'date_completed': datetime.datetime.now()
                    })
                    
                    # Update user stats
                    update_user_stats(session['user_id'], 'assessments_completed')
                except Exception as db_error:
                    print(f"Database error: {db_error}")
                    # Continue with the quiz result even if we can't save to db
            
            # Store the quiz results in the session for the results page to access
            session['quiz_results'] = {
                'score': score,
                'results': results,
                'recommendations': recommendations,
                'answers': answers,
                'mood': mood
            }
            
            # Direct redirect to results page, no JSON response
            return redirect(url_for('quiz_results'))
                                  
        except Exception as e:
            print(f"Error in processing quiz: {e}")
            import traceback
            traceback.print_exc()  # Print the full traceback for debugging
            return render_template('error.html', 
                                  title="Error Processing Quiz",
                                  message="There was an error processing your quiz. Please try again.")

    # If not POST method, redirect to quiz page
    return redirect(url_for('quiz'))

@app.route('/quiz_results')
def quiz_results():
    # Get the quiz results from the session
    quiz_data = session.get('quiz_results')
    
    if not quiz_data:
        # No quiz results in session, redirect to assessments page
        return redirect(url_for('other_quizzes'))
    
    # Render the results template with the data from session
    return render_template('quiz_results.html',
                         score=quiz_data.get('score'),
                         results=quiz_data.get('results'),
                         recommendations=quiz_data.get('recommendations'),
                         answers=quiz_data.get('answers'),
                         mood=quiz_data.get('mood'))

@app.route('/skip_quiz')
def skip_quiz():
    if 'user_id' not in session:
        return redirect(url_for('login')) # Redirect to login if not logged in

    user_id = session['user_id']
    # Mark initial quiz as skipped for the user
    db.users.update_one({'_id': ObjectId(user_id)}, {'$set': {'initial_quiz_completed': True}})

    return redirect(url_for('index')) # Redirect to homepage

@app.route('/articles')
def articles():
    # TODO: Fetch articles from database
    articles_list = [] # Placeholder
    return render_template('articles.html', articles=articles_list)

@app.route('/meditation')
def meditation():
    # TODO: Fetch meditation recommendations from database
    meditation_list = [] # Placeholder
    return render_template('meditation.html', meditation=meditation_list)

@app.route('/other_quizzes')
def other_quizzes():
    # TODO: Fetch other quizzes from database
    quizzes_list = [] # Placeholder
    return render_template('other_quizzes.html', quizzes=quizzes_list)

@app.route('/contact')
def contact():
    # Fetch counselor details from database
    counselors_list = list(db.counselors.find())  # Convert cursor to list
    return render_template('contact.html', counselors=counselors_list)

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Find user and check if they are an admin
        user = db.users.find_one({'email': email, 'is_admin': True})

        if user and check_password_hash(user['password'], password):
            # Admin login successful
            session['user_id'] = str(user['_id'])
            session['is_admin'] = True
            return redirect(url_for('admin_dashboard')) # Redirect to admin dashboard
        else:
            # Admin login failed
            return "Invalid credentials or not an admin!" # Placeholder
    return render_template('admin_login.html')

@app.route('/chat')
def chat():
    return render_template('chatbot.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Get user from database using the user_profiles view
    try:
        user = db.users.find_one({'_id': ObjectId(session['user_id'])})
        
        if not user:
            # Invalid session or user deleted
            session.clear()
            return redirect(url_for('login'))
        
        # Convert to dictionary for template
        user_dict = {
            'id': user['_id'],
            'username': user['email'],
            'email': user['email'],
            'first_name': user.get('first_name', ''),
            'last_name': user.get('last_name', ''),
            'phone': user.get('phone', ''),
            'created_at': user['created_at'] if 'created_at' in user else None,
            'assessments_completed': user.get('assessments_completed', 0),
            'chat_sessions': user.get('chat_sessions', 0),
            'meditation_minutes': user.get('meditation_minutes', 0),
            'last_login': user['last_login'] if 'last_login' in user else None
        }
        
        return render_template('profile.html', user=user_dict)
    
    except Exception as e:
        print(f"Error fetching user profile: {e}")
        return redirect(url_for('login'))

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    first_name = request.form.get('first_name', '')
    last_name = request.form.get('last_name', '')
    email = request.form.get('email', '')
    phone = request.form.get('phone', '')
    
    # Validate email format
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        flash('Please enter a valid email address.', 'danger')
        return redirect(url_for('profile'))
    
    try:
        # Check if email already exists for a different user
        existing_user = db.users.find_one({'email': email, '_id': {'$ne': ObjectId(session['user_id'])}})
        
        if existing_user:
            flash('Email address is already in use by another account.', 'danger')
            return redirect(url_for('profile'))
        
        # Update user information
        db.users.update_one({'_id': ObjectId(session['user_id'])}, {
            '$set': {
                'first_name': first_name,
                'last_name': last_name,
                'email': email,
                'phone': phone,
                'last_login': datetime.datetime.now()
            }
        })
        
        flash('Your profile has been updated successfully.', 'success')
        return redirect(url_for('profile'))
    
    except Exception as e:
        print(f"Error updating profile: {e}")
        flash('An error occurred while updating your profile. Please try again.', 'danger')
        return redirect(url_for('profile'))

@app.route('/contact_submit', methods=['POST'])
def contact_submit():
    # Get form data
    name = request.form.get('name')
    email = request.form.get('email')
    phone = request.form.get('phone', '')
    concern = request.form.get('concern')
    message = request.form.get('message')
    
    # Save to database
    contact_request = {
        'name': name,
        'email': email,
        'phone': phone,
        'concern': concern,
        'message': message,
        'date_submitted': datetime.datetime.now(),
        'status': 'new'
    }
    
    db.contact_requests.insert_one(contact_request)
    
    # Could send email notification here
    
    # Flash a success message and redirect
    return render_template('contact_success.html')

@app.route('/generate_custom_quiz', methods=['POST'])
def generate_custom_quiz():
    # Check if request is POST
    if request.method != 'POST':
        return redirect(url_for('other_quizzes'))
    
    # Get form data
    topic = request.form.get('topic')
    num_questions = int(request.form.get('num_questions', 10))
    difficulty = request.form.get('difficulty', 'intermediate')
    custom_prompt = request.form.get('custom_prompt', '')
    
    try:
        # Generate prompt for Gemini
        prompt = f"""
        Create a mental health quiz about {topic} with {num_questions} questions at {difficulty} level.
        {custom_prompt if custom_prompt else ''}
        
        Format each question as a JSON object with the following structure:
        {{
            "question": "The question text",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correct_answer": "The correct option text"
        }}
        
        Return a JSON array of these question objects.
        """
        
        # Generate questions using Gemini
        response = gemini_model.generate_content(prompt)
        
        if response and hasattr(response, 'text'):
            questions_text = response.text
            
            # Parse the response
            try:
                # Clean up and parse the JSON
                questions_text = questions_text.strip()
                if questions_text.startswith('```json'):
                    questions_text = questions_text.replace('```json', '', 1)
                if questions_text.endswith('```'):
                    questions_text = questions_text[:-3]
                
                questions = json.loads(questions_text.strip())
                
                # Save the quiz to the database if user is logged in
                if 'user_id' in session:
                    quiz_data = {
                        'user_id': session['user_id'],
                        'topic': topic,
                        'difficulty': difficulty,
                        'questions': questions,
                        'created_at': datetime.datetime.now()
                    }
                    db.custom_quizzes.insert_one(quiz_data)
                
                # Render the quiz page with the questions
                return render_template('custom_quiz.html', 
                                      questions=questions, 
                                      topic=topic,
                                      difficulty=difficulty)
            
            except json.JSONDecodeError as e:
                print(f"Error parsing questions JSON: {e}")
                print(f"Original text: {questions_text}")
                return render_template('error.html', 
                                      message="There was an error generating your quiz. Please try again.")
        else:
            return render_template('error.html', 
                                  message="There was an error generating your quiz. Please try again.")
    
    except Exception as e:
        print(f"Error generating custom quiz: {e}")
        return render_template('error.html', 
                              message="There was an error generating your quiz. Please try again.")

def update_user_stats(user_id, stat_type, value=1):
    """Update user stats in the database
    
    Args:
        user_id: The user ID
        stat_type: The type of stat to update (assessments_completed, chat_sessions, meditation_minutes)
        value: The value to increment by (default 1)
    """
    if 'user_id' not in session:
        return  # Only track stats for logged in users
    
    try:
        # Update the specific stat using MongoDB's $inc operator
        update_data = {
            '$inc': {stat_type: value},
            '$set': {'last_login': datetime.datetime.now()}
        }
        
        db.users.update_one({'_id': ObjectId(user_id)}, update_data)
    except Exception as e:
        print(f"Error updating user stats: {e}")

@app.route('/send_message', methods=['POST'])
def send_message():
    user_message = request.form.get('message')
    if not user_message:
        return jsonify({'error': 'No message provided'}), 400
    
    try:
        # Send message to Gemini and get response
        response = mental_health_chat.send_message(user_message)
        # Convert markdown to HTML for proper rendering
        response_html = markdown.markdown(response.text)
        
        # Update chat sessions stat if user is logged in
        if 'user_id' in session:
            update_user_stats(session['user_id'], 'chat_sessions')
            
        return jsonify({'response': response_html})
    except Exception as e:
        print(f"Error in chat: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/change_password', methods=['POST'])
def change_password():
    if 'user_id' not in session:
        return jsonify({'status': 'error', 'message': 'You must be logged in to change your password.'}), 401
    
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    # Validate inputs
    if not all([current_password, new_password, confirm_password]):
        return jsonify({'status': 'error', 'message': 'All fields are required.'}), 400
    
    if new_password != confirm_password:
        return jsonify({'status': 'error', 'message': 'New passwords do not match.'}), 400
    
    if len(new_password) < 8:
        return jsonify({'status': 'error', 'message': 'Password must be at least 8 characters long.'}), 400
    
    try:
        # Verify current password
        user = db.users.find_one({'_id': ObjectId(session['user_id'])})
        
        if not check_password_hash(user['password'], current_password):
            return jsonify({'status': 'error', 'message': 'Current password is incorrect.'}), 400
        
        # Update password
        hashed_password = generate_password_hash(new_password)
        db.users.update_one({'_id': ObjectId(session['user_id'])}, {'$set': {'password': hashed_password}})
        
        return jsonify({'status': 'success', 'message': 'Password updated successfully.'}), 200
    
    except Exception as e:
        print(f"Error changing password: {e}")
        return jsonify({'status': 'error', 'message': 'An error occurred. Please try again.'}), 500

# Get current year for footer copyright
@app.context_processor
def inject_now():
    return {'now': datetime.datetime.now()}

def init_db():
    """Initialize the database with initial collections if needed"""
    try:
        # Check if collections exist, create them if they don't
        if "users" not in db.list_collection_names():
            db.create_collection("users")
            print("Created users collection")
            
        if "quiz_results" not in db.list_collection_names():
            db.create_collection("quiz_results")
            print("Created quiz_results collection")
            
        if "custom_quizzes" not in db.list_collection_names():
            db.create_collection("custom_quizzes")
            print("Created custom_quizzes collection")
            
        if "contact_requests" not in db.list_collection_names():
            db.create_collection("contact_requests")
            print("Created contact_requests collection")
            
        print("Database initialized successfully.")
    except Exception as e:
        print(f"Error initializing database: {e}")

# Initialize the database on startup
init_db()

@app.route('/track_meditation', methods=['POST'])
def track_meditation():
    if 'user_id' not in session:
        return jsonify({'status': 'error', 'message': 'You must be logged in to track meditation.'}), 401
    
    minutes = request.json.get('minutes', 0)
    
    try:
        # Validate minutes
        minutes = int(minutes)
        if minutes <= 0:
            return jsonify({'status': 'error', 'message': 'Invalid meditation time.'}), 400
        
        # Update meditation minutes
        update_user_stats(session['user_id'], 'meditation_minutes', minutes)
        
        return jsonify({
            'status': 'success', 
            'message': f'Successfully logged {minutes} minutes of meditation.'
        }), 200
    
    except ValueError:
        return jsonify({'status': 'error', 'message': 'Invalid meditation time format.'}), 400
    except Exception as e:
        print(f"Error tracking meditation: {e}")
        return jsonify({'status': 'error', 'message': 'An error occurred. Please try again.'}), 500

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))
    
    try:
        # Get statistics
        total_users = db.users.count_documents({})
        total_quizzes = db.quiz_results.count_documents({})
        total_contacts = db.contact_requests.count_documents({})
        total_meditation = db.users.aggregate([
            {'$group': {'_id': None, 'total': {'$sum': '$meditation_minutes'}}}
        ]).next()['total'] if db.users.count_documents({}) > 0 else 0
        
        # Get users list
        users = list(db.users.find({'is_admin': False}))
        
        # Get contact requests
        contacts = list(db.contact_requests.find().sort('date_submitted', -1))
        
        # Get quiz results with user emails
        quizzes = list(db.quiz_results.aggregate([
            {
                '$lookup': {
                    'from': 'users',
                    'localField': 'user_id',
                    'foreignField': '_id',
                    'as': 'user'
                }
            },
            {'$unwind': '$user'},
            {'$project': {
                '_id': 1,
                'quiz_id': 1,
                'score': 1,
                'date_completed': 1,
                'user_email': '$user.email'
            }}
        ]))
        
        # Get admin list
        admins = list(db.users.find({'is_admin': True}))
        
        return render_template('admin_dashboard.html',
                             total_users=total_users,
                             total_quizzes=total_quizzes,
                             total_contacts=total_contacts,
                             total_meditation=total_meditation,
                             users=users,
                             contacts=contacts,
                             quizzes=quizzes,
                             admins=admins)
    
    except Exception as e:
        print(f"Error loading admin dashboard: {e}")
        return render_template('error.html', message="Error loading admin dashboard")

@app.route('/admin/add_admin', methods=['POST'])
def add_admin():
    if not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        email = request.form.get('email')
        password = request.form.get('password')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        
        # Check if admin already exists
        if db.users.find_one({'email': email}):
            return jsonify({'success': False, 'message': 'Email already exists'})
        
        # Create new admin
        hashed_password = generate_password_hash(password)
        db.users.insert_one({
            'email': email,
            'password': hashed_password,
            'first_name': first_name,
            'last_name': last_name,
            'is_admin': True,
            'created_at': datetime.datetime.now()
        })
        
        return jsonify({'success': True})
    
    except Exception as e:
        print(f"Error adding admin: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/admin/delete_admin/<admin_id>', methods=['POST'])
def delete_admin(admin_id):
    if not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Don't allow deleting the last admin
        admin_count = db.users.count_documents({'is_admin': True})
        if admin_count <= 1:
            return jsonify({'success': False, 'message': 'Cannot delete the last admin'})
        
        # Delete the admin
        result = db.users.delete_one({'_id': ObjectId(admin_id), 'is_admin': True})
        
        if result.deleted_count > 0:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Admin not found'})
    
    except Exception as e:
        print(f"Error deleting admin: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/admin/delete_user/<user_id>', methods=['POST'])
def delete_user(user_id):
    if not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        # Delete user and their associated data
        result = db.users.delete_one({'_id': ObjectId(user_id), 'is_admin': False})
        
        if result.deleted_count > 0:
            # Delete associated quiz results
            db.quiz_results.delete_many({'user_id': user_id})
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'User not found'})
    
    except Exception as e:
        print(f"Error deleting user: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/admin/update_contact_status/<contact_id>', methods=['POST'])
def update_contact_status(contact_id):
    if not session.get('is_admin'):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    
    try:
        new_status = request.json.get('status')
        if new_status not in ['new', 'in_progress', 'resolved']:
            return jsonify({'success': False, 'message': 'Invalid status'})
        
        result = db.contact_requests.update_one(
            {'_id': ObjectId(contact_id)},
            {'$set': {'status': new_status}}
        )
        
        if result.modified_count > 0:
            return jsonify({'success': True})
        else:
            return jsonify({'success': False, 'message': 'Contact request not found'})
    
    except Exception as e:
        print(f"Error updating contact status: {e}")
        return jsonify({'success': False, 'message': str(e)})

@app.route('/admin/view_user/<user_id>')
def admin_view_user(user_id):
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))

    try:
        user = db.users.find_one({'_id': ObjectId(user_id)})
        if not user:
            return render_template('error.html', message="User not found")

        return render_template('admin_view_user.html', user=user)

    except Exception as e:
        print(f"Error viewing user: {e}")
        return render_template('error.html', message="Error loading user details")

@app.route('/admin/view_contact/<contact_id>')
def admin_view_contact(contact_id):
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))

    try:
        contact = db.contact_requests.find_one({'_id': ObjectId(contact_id)})
        if not contact:
            return render_template('error.html', message="Contact request not found")

        return render_template('admin_view_contact.html', contact=contact)

    except Exception as e:
        print(f"Error viewing contact request: {e}")
        return render_template('error.html', message="Error loading contact request details")

@app.route('/admin/view_quiz_result/<result_id>')
def admin_view_quiz_result(result_id):
    if not session.get('is_admin'):
        return redirect(url_for('admin_login'))

    try:
        quiz_result = db.quiz_results.find_one({'_id': ObjectId(result_id)})
        if not quiz_result:
            return render_template('error.html', message="Quiz result not found")

        # Optionally fetch user details for the quiz result
        user = db.users.find_one({'_id': ObjectId(quiz_result.get('user_id'))})
        quiz_result['user_email'] = user.get('email', 'N/A') if user else 'N/A'

        return render_template('admin_view_quiz_result.html', quiz_result=quiz_result)

    except Exception as e:
        print(f"Error viewing quiz result: {e}")
        return render_template('error.html', message="Error loading quiz result details")

if __name__ == '__main__':
    app.run(debug=True)
